		<br/><br/>
		</div>
		
		<div id="pied">
			<table>
				<tr>
					<th>Nos Partenaires</th>
					<th>Statut L�gal</th>
				</tr>
				<tr>
					<td>Lol on en a pas</td>
					<td>Blabla</td>
				</tr>
			</table>
		</div>
	
</body>
</html>
